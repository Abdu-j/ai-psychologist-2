export default async function handler(req, res) {
  const { message } = req.body;
  // Simple mock response
  const reply = `I understand. Can you tell me more about why you feel "${message}"?`;
  res.status(200).json({ reply });
}
