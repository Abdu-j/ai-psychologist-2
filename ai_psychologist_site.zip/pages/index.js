import { useState } from 'react';

export default function Home() {
  const [messages, setMessages] = useState([{ role: 'ai', text: 'Hi, I'm your AI psychologist. What's on your mind?' }]);
  const [input, setInput] = useState('');

  const sendMessage = async () => {
    if (!input.trim()) return;
    const userMessage = { role: 'user', text: input };
    setMessages([...messages, userMessage]);
    setInput('');

    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: input })
    });

    const data = await res.json();
    setMessages([...messages, userMessage, { role: 'ai', text: data.reply }]);
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h1>AI Psychologist</h1>
      <div style={{ border: '1px solid #ccc', padding: '10px', height: '300px', overflowY: 'auto' }}>
        {messages.map((msg, i) => (
          <div key={i}><b>{msg.role === 'user' ? 'You' : 'AI'}:</b> {msg.text}</div>
        ))}
      </div>
      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
        placeholder="Type here..."
        style={{ width: '80%', padding: '8px', marginTop: '10px' }}
      />
      <button onClick={sendMessage} style={{ padding: '8px 16px', marginLeft: '10px' }}>Send</button>
    </div>
  );
}
